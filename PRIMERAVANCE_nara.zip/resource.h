//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por PRIMERAVANCE_nara.rc
//
#define MODIFICAR                       1
#define IDC_MYICON                      2
#define IDD_PRIMERAVANCENARA_DIALOG     102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDI_PRIMERAVANCENARA            107
#define IDI_SMALL                       108
#define IDC_PRIMERAVANCENARA            109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define INICIO_SES                      129
#define IDD_DIALOG2                     130
#define REGISTRO                        130
#define IDD_DIALOG3                     131
#define AGENDA                          131
#define IDD_DIALOG4                     132
#define CITA                            132
#define IDR_MENU2                       135
#define INF_DOC                         135
#define IDR_MENU1                       136
#define IDD_ABOUTBOX                    137
#define IDC_BUTTON3                     1002
#define INICIO                          1002
#define IDC_EDIT2                       1004
#define IDC_EDIT3                       1005
#define IDC_EDIT1                       1007
#define IDC_EDIT4                       1009
#define IDC_EDIT5                       1010
#define IDC_BUTTON1                     1011
#define IDC_LIST1                       1012
#define IDC_DATETIMEPICKER1             1014
#define IDC_DATETIMEPICKER2             1015
#define IDC_EDIT6                       1016
#define IDC_EDIT7                       1017
#define IDC_SCROLLBAR2                  1019
#define IDC_COMBO1                      1020
#define IDC_COMBO2                      1021
#define IDC_SCROLLBAR1                  1023
#define REGIS                           1024
#define ACEPTAR                         1025
#define AGENDAR                         1026
#define RETORNO                         1027
#define IDC_USUARIO                     1028
#define IDC_CONTRA                      1029
#define IDC_NOM                         1030
#define IDC_TEL                         1031
#define IDC_MASC                        1032
#define IDC_MOT                         1033
#define IDC_COST                        1034
#define IDC_BUSCAR                      1035
#define IDC_FOTO                        1036
#define IDC_COMBO4                      1038
#define IDC_COMBO8                      1040
#define IDC_COMBO9                      1041
#define IDC_EDIT_NOM_DOCTOR             1042
#define IDC_EDIT_CONTRA_DOCTOR          1043
#define IDC_EDIT_CED_DOCTOR             1044
#define IDC_EDIT_US_DOCTOR              1045
#define ID_LOL_LOL1                     32772
#define ID_LOL_LOL2                     32773
#define ID_LOL_LOL3                     32774
#define ID_LOL_SALIR                    32775
#define ID_INICIO                       32776
#define IDD_INICIO                      32777
#define ID_AGENDA                       32778
#define ID_CITAS                        32779
#define ID_CUENTA                       32780
#define ID_SALIR                        32781
#define ID_HOLA_ADIOSUNU                32782
#define ID_HOLA_MALA                    32783
#define IDC_EXIT                        32784
#define IDM_EXIT                        32785
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
